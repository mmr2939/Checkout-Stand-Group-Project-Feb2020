#include "Register.h"



Register::Register()
{
}


Register::~Register()
{
}
