#pragma once
class Register
{
public:
	Register();
	~Register();
};

