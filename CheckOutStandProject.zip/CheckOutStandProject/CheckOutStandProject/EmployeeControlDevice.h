#pragma once
class EmployeeControlDevice
{
public:
	EmployeeControlDevice();
	~EmployeeControlDevice();
};

