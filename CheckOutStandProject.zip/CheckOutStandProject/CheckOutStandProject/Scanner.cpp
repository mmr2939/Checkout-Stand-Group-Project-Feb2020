#include "Scanner.h"



Scanner::Scanner()
{
}


Scanner::~Scanner()
{
}
