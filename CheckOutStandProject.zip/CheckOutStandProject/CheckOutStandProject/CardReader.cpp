#include "CardReader.h"



CardReader::CardReader()
{
}


CardReader::~CardReader()
{
}
