#include <iostream>

using std::cout;
using std::endl;

int main() 
{
	
	cout << " Welcome to Von's!" << endl;



	return 0;
}