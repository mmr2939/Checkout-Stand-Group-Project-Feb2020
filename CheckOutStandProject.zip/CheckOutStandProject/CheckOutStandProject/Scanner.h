#pragma once
class Scanner
{
public:
	Scanner();
	~Scanner();
};

