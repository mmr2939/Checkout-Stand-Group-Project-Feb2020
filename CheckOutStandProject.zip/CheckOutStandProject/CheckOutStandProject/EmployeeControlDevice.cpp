#include "EmployeeControlDevice.h"



EmployeeControlDevice::EmployeeControlDevice()
{
}


EmployeeControlDevice::~EmployeeControlDevice()
{
}
