#pragma once
class CardReader
{
public:
	CardReader();
	~CardReader();
};

